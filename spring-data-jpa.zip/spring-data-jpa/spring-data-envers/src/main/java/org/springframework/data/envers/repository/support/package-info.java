/**
 * Spring Data JPA specific converter infrastructure.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.envers.repository.support;
