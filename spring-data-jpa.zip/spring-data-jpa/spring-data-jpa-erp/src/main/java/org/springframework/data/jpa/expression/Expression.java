package org.springframework.data.jpa.expression;

public interface Expression<U, V> {
	
	public U getLeft();
	
	public V getRight();
	
	public String getOperator();
	
	//public Expression getExpression();
	
	
}
