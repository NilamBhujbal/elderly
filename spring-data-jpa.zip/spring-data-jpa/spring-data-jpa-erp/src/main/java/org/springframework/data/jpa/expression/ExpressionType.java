package org.springframework.data.jpa.expression;

public enum ExpressionType {
	SIMPLE, NESTED;
	
}
