package org.springframework.data.jpa.expression;

public class NestedExpression implements Expression<SimpleExpression, NestedExpression> {
	
	private SimpleExpression left;
	
	private NestedExpression right;
	
	private String operator;
	
	public void setLeft(SimpleExpression left) {
		this.left = left;
	}

	public void setRight(NestedExpression right) {
		this.right = right;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	@Override
	public SimpleExpression getLeft() {
		return left;
	}

	@Override
	public NestedExpression getRight() {
		return right;
	}

	@Override
	public String getOperator() {
		return operator;
	}
	
	public void addExpression(Expression expression) {
		if (getLeft()==null) {
			setLeft((SimpleExpression) expression);
		} else if (getRight()==null) {
			setRight((NestedExpression) expression);
		}
	}

	@Override
	public String toString() {
		return "NestedExpression [left=" + left + ", right=" + right + ", operator=" + operator + "]";
	}
}