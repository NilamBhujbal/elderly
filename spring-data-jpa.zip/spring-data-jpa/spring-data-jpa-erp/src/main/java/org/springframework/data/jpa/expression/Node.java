package org.springframework.data.jpa.expression;

public class Node {
	
	private Expression right;
	
	private String operator;
	
	private Expression left;
	
	private Node next;
	
	public Node() {
		super();
	}

	public Node(Expression right, String operator, Expression left) {
		super();
		this.right = right;
		this.operator = operator;
		this.left = left;
	}

	public Node(Expression right, String operator, Expression left, Node next) {
		this(right, operator, left);
		this.next = next;
	}
	
	public void setRight(Expression right) {
		this.right = right;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public void setLeft(Expression left) {
		this.left = left;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}

	public Expression getRight() {
		return right;
	}

	public String getOperator() {
		return operator;
	}

	public Expression getLeft() {
		return left;
	}
	
	public void addExpression(Expression expression) {
		if (getLeft()!=null && getLeft() instanceof NestedExpression nest && nest.getRight()==null && nest.getLeft()!=null) {
			if (expression instanceof SimpleExpression) {
				NestedExpression nestedEpr = new NestedExpression();
				nestedEpr.addExpression(expression);
				nest.setRight(nestedEpr);
			} else {
				nest.setRight((NestedExpression) expression);
			}
			
		} else if (getLeft()==null) {
			setLeft(expression);
		} else if (getRight()==null) {
			setRight(expression);
		}
	}
	
	public boolean addOperator(String operator) {
		if (getLeft()!=null && getLeft() instanceof NestedExpression nest && nest.getOperator()==null && nest.getRight()==null && nest.getLeft()!=null) {
			nest.setOperator(operator);
			return true;
		} else if (getLeft()!=null && getRight() instanceof NestedExpression nest && this.operator!=null && nest.getRight()!=null && nest.getLeft()!=null) {
			this.operator = operator;
			return true;
		}
		return false;
	}
	
	public Node getNextNode() {
		if (getRight() != null) {
			this.next = new Node();
			return this.next;
		}
		return this;
	}

	@Override
	public String toString() {
		return "Node [right=" + right + ", operator=" + operator + ", left=" + left + ", next=" + next + "]";
	}
}
