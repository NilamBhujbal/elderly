package org.springframework.data.jpa.expression;

public enum NodeEnum {
	NONE, LEFT, OPERATOR, RIGHT;

	public static NodeEnum getNext(int index) {
		NodeEnum nodeEnum = NodeEnum.NONE;
		switch (index) {
		case 1:
			nodeEnum = NodeEnum.LEFT;
			break;
		case 2:
			nodeEnum = NodeEnum.OPERATOR;
			break;
		case 3:
			nodeEnum = NodeEnum.RIGHT;
			break;
		}
		return nodeEnum;
	}
}
