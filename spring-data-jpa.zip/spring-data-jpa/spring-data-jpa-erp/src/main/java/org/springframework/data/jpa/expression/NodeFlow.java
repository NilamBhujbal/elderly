package org.springframework.data.jpa.expression;

public enum NodeFlow {
	START, STOP, YET_TO_START, CREATE_EXPRESSION, NESTED_EXPRESSION;
}
