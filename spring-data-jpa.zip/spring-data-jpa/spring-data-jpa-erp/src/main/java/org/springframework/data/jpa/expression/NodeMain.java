package org.springframework.data.jpa.expression;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.util.StringUtils;

public class NodeMain {

	public static void main(String[] args) {
		String expression = "(('T', '=', 'V'), '&', ('E', '=', '1')), '|', ('P', '=', 'C')";
		// String expression = "('P', '=', 'C')";
		NodeFlow flow = NodeFlow.YET_TO_START;
		ExpressionType expressionType = ExpressionType.SIMPLE;

		Node node = new Node();
		Node root = node;
		int size = expression.length(), count = 0, next = 0;
		List<Character> characters = new ArrayList<Character>();
		Expression current = null;
		String left = "", right = "", operator = "";
		for (int index = 0; index < size; index++) {
			NodeEnum nodeEnum = NodeEnum.getNext(next);
			char ch = expression.charAt(index);
			if (ch == '(') {
				count++;
			} else if (ch == ')') {
				count--;
			} else
			
			if (count > 1) {
				expressionType = ExpressionType.NESTED;
			} else {
				expressionType = ExpressionType.SIMPLE;
			}

			if (NodeFlow.START == flow && ch == '\'') {
				flow = NodeFlow.STOP;
			} else if (flow == NodeFlow.START) {
				characters.add(ch);
			} else if (NodeFlow.STOP == flow) {
				String value = characters.stream().map(c -> String.valueOf(c)).collect(Collectors.joining());
				if (nodeEnum == NodeEnum.LEFT) {
					left = value;
				} else if (nodeEnum == NodeEnum.OPERATOR) {
					operator = value;
					System.out.println("OPERATOR: " + operator);
					if (node.addOperator(operator)) {
						operator = "";
						System.out.println("NESTEDC" + root);
						next = 0;
					}
				} else if (nodeEnum == NodeEnum.RIGHT) {
					right = value;
					next = 0;
					flow = NodeFlow.CREATE_EXPRESSION;
				}
			}
			System.out.println(expressionType + " || " + count);
			if (flow == NodeFlow.CREATE_EXPRESSION) {
				if (expressionType == ExpressionType.NESTED) {
					next = 1;
					SimpleExpression simpleEpr = new SimpleExpression(left, operator, right);
					NestedExpression nestedEpr = new NestedExpression();
					nestedEpr.addExpression(simpleEpr);
					node.addExpression(nestedEpr);
					node = node.getNextNode();
					operator = "";
					System.out.println(root);
				} else if (expressionType == ExpressionType.SIMPLE) {
					SimpleExpression simpleEpr = new SimpleExpression(left, operator, right);
					node.addExpression(simpleEpr);
					node = node.getNextNode();
					operator = "";
					next = 0;
					left = "";
					right = "";
				}
			}

			if (flow == NodeFlow.YET_TO_START && (ch == '\'' || Character.isAlphabetic(ch))) {
				flow = NodeFlow.START;
				next = !StringUtils.isEmpty(left) && StringUtils.isEmpty(operator) || next == 3 ? next
						: next > 3 ? 0 : next + 1;
				System.out.println(next);
				characters = new ArrayList<Character>();
			} else if (ch == ',') {
				next = next > 2 ? 0 : next + 1;
				flow = NodeFlow.YET_TO_START;
			}
		}
		System.out.println(root);
	}

	public static Expression createSimpleExpression(Character ch, String flow, List<Character> characters) {

		return null;

	}
}
