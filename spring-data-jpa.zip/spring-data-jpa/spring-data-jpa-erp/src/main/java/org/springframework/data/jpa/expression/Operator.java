package org.springframework.data.jpa.expression;

public class Operator {
	
	String operator;
	
}
