package org.springframework.data.jpa.expression;

public class SimpleExpression implements Expression<String, String> {
	
	private String left;
	
	private String operator;
	
	private String right;
	
	public SimpleExpression(String left, String operator, String right) {
		super();
		this.left = left;
		this.operator = operator;
		this.right = right;
	}

	@Override
	public String getLeft() {
		return this.left;
	}

	@Override
	public String getRight() {
		return this.right;
	}

	@Override
	public String getOperator() {
		return this.operator;
	}

	@Override
	public String toString() {
		return "SimpleExpression [left=" + left + ", operator=" + operator + ", right=" + right + "]";
	}
}
