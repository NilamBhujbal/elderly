package org.springframework.data.jpa.repository.specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.fasterxml.jackson.databind.introspect.BasicBeanDescription;

public class ErpSpecification<T> implements Specification<T>  {

	@Override
	public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
		Predicate p1 = cb.equal(root.get("active"), true);
		return p1;
	}
}
