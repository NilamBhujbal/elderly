package org.springframework.demo.data;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

//@EnableJpaRepositories
@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(DemoApplication.class, args);
		LocalContainerEntityManagerFactoryBean lemf = context.getBean(LocalContainerEntityManagerFactoryBean.class);
		List<String> managed = lemf.getPersistenceUnitInfo().getManagedClassNames();
		for (String m : managed) {
			System.out.println(m);
		}
	}
}
