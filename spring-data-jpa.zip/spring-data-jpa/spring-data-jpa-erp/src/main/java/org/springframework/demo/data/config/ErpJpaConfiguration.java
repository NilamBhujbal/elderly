package org.springframework.demo.data.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.repository.support.ErpJpaRepositoryFactoryBean;

@Configuration
@EnableJpaRepositories(repositoryFactoryBeanClass = ErpJpaRepositoryFactoryBean.class, basePackages = {
		"org.springframework.demo.data.erp.repository" })
public class ErpJpaConfiguration {

}
