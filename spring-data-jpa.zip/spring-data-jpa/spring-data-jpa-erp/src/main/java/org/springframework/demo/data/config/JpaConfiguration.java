package org.springframework.demo.data.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = { "org.springframework.demo.data.repository" })
public class JpaConfiguration {

}
