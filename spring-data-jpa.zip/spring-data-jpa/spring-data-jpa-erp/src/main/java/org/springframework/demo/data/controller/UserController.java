package org.springframework.demo.data.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.demo.data.domain.User;
import org.springframework.demo.data.erp.domain.Lead;
import org.springframework.demo.data.erp.repository.LeadRepository;
import org.springframework.demo.data.repository.UserRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private LeadRepository leadRepository;
	
	@PostMapping(value = "/user")
	public List<User> create(@RequestBody User user) {
		this.userRepository.save(user);
		return this.userRepository.findAll();
	}
	
	@PostMapping(value = "/lead")
	@Transactional
	public List<Lead> createLead(@RequestBody Lead lead) {
		this.leadRepository.save(lead);
		List<Lead> leads = this.leadRepository.findAll();
		return leads;
	}
	
	@GetMapping(value = "/lead")
	public List<Lead> findLead() {
		return this.leadRepository.findAll();
	}
}
