package org.springframework.demo.data.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RULE_TBL")
public class Rule implements Serializable {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "RULE_MODEL")
	private String model;

	@Column(name = "RULE_DOMAIN")
	private String domain;

	@Column(name = "RULE_READ")
	private boolean read = true;

	@Column(name = "RULE_WRITE")
	private boolean write = true;

	@Column(name = "RULE_DELETE")
	private boolean delete = true;

	@Column(name = "RULE_CREATE")
	private boolean create = true;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public boolean isRead() {
		return read;
	}

	public void setRead(boolean read) {
		this.read = read;
	}

	public boolean isWrite() {
		return write;
	}

	public void setWrite(boolean write) {
		this.write = write;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}

	public boolean isCreate() {
		return create;
	}

	public void setCreate(boolean create) {
		this.create = create;
	}
}
