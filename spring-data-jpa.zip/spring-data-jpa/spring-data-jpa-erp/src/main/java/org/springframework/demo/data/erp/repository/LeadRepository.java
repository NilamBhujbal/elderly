package org.springframework.demo.data.erp.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.demo.data.domain.User;
import org.springframework.demo.data.erp.domain.Lead;

public interface LeadRepository extends JpaRepository<Lead, Serializable> {

}
