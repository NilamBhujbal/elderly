package org.springframework.demo.data.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.demo.data.domain.Rule;

public interface RuleRepository extends JpaRepository<Rule, Serializable> {

}
