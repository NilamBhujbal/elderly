package org.springframework.demo.data.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.demo.data.domain.User;

public interface UserRepository extends JpaRepository<User, Serializable> {

}
