package org.springframework.demo.data.sample;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.demo.data.domain.Rule;
import org.springframework.demo.data.erp.domain.Lead;
import org.springframework.demo.data.erp.repository.LeadRepository;
import org.springframework.demo.data.repository.RuleRepository;
import org.springframework.stereotype.Component;

@Component
public class SampleDataRepository {
	
	@Autowired
	private RuleRepository ruleRepository;
	
	@Autowired
	private LeadRepository leadRepository;
	
	public SampleDataRepository() {
	//	initLeadRepository();
	//	initRuleRepository();
	}
	
	public void initRuleRepository() {
		List<Rule> rules = new ArrayList<>();
		
		Rule rule = new Rule();
		rule.setModel("org.springframework.demo.data.erp.domain.Lead");
		rule.setDomain("[('active', '=', 'true')]");
		
		rules.add(rule);
		
		ruleRepository.saveAll(rules);
	}
	
	public void initLeadRepository() {
		List<Lead> leads = new ArrayList<Lead>();
		Lead lead = new Lead();
		lead.setName("Test 1");
		
		leadRepository.save(lead);
	}
	
	
}
