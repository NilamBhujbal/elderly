package org.springframework.demo.data.spi;

import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.net.URL;
import java.util.Collection;
import java.util.List;

import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ErpClassLoaderServiceImpl implements ClassLoaderService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ErpClassLoaderServiceImpl.class);

	@Override
	public void stop() {
	}

	@Override
	public <T> Class<T> classForName(String className) {
		LOGGER.info("ClassName: "+ className);
		return null;
	}

	@Override
	public URL locateResource(String name) {
		return null;
	}

	@Override
	public InputStream locateResourceStream(String name) {
		return null;
	}

	@Override
	public List<URL> locateResources(String name) {
		return null;
	}

	@Override
	public <S> Collection<S> loadJavaServices(Class<S> serviceContract) {
		return null;
	}

	@Override
	public <T> T generateProxy(InvocationHandler handler, Class... interfaces) {
		return null;
	}

	@Override
	public Package packageForNameOrNull(String packageName) {
		return null;
	}

	@Override
	public <T> T workWithClassLoader(Work<T> work) {
		return null;
	}

}
