/**
 * JPA specific support classes for the Spring Data mapping subsystem.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.mapping;
