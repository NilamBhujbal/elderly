/**
 * JPA provider-specific utilities.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.provider;
